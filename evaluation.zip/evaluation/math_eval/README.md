# Evaluation of COSE on Math Benchmarks

### Requirements
You can install the required packages with the following command:
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source $HOME/.local/bin/env

# Install latex2sympy
cd evaluation/math_eval
uv venv --python 3.10.14
source .venv/bin/activate
uv pip install setuptools wheel build
cd eval
tar -xzvf latex2sympy.tar.gz 
cd latex2sympy
uv pip install -e .
cd ../..
# Install other packages. 
uv pip install -r requirements.txt

# Install flash-attn
uv pip install flash_attn==2.7.4.post1 --no-build-isolation
uv pip install pyarrow==19.0.1
```
> Note the `requirements.txt` doesn't limit packages versions. You can use `freezed_requirements.txt` to install all freezed versions but might include some unused packages. For example, when you install, you may install the latest version of `pyarrow` results in errors. Then you can look into `freezed_requirements.txt` and install the specific version of `pyarrow` as shown above.

### Evaluation

Place your trained COSE checkpoint under `./models/`, and (optionally) download the base model used as a baseline:

```bash
cd evaluation/math_eval
source .venv/bin/activate

# Put your trained COSE checkpoint here:
#   ./models/<your-cose-checkpoint>
# (point --init_model at it below)

# Download the Qwen2.5-7B base model (baseline)
hf download Qwen/Qwen2.5-7B --local-dir-use-symlinks False --local-dir ./models/Qwen2.5-7B
```

Use the following script to evaluate your COSE model on 6 benchmarks with greedy decoding.

```bash
# eval COSE
bash eval_math_nodes.sh \
    --run_name cose_base_7b_seed2 \
    --init_model <your absolute path to>/models/<your-cose-checkpoint> \
    --template cose \
    --tp_size 1 \
    --add_step_0 true \
    --temperature 0 \
    --top_p 0.95 \
    --max_tokens 16000 \
    --benchmarks aime24,aime25,amc23,math500,olympiadbench,minerva_math \
    --n_sampling 1 \
    --just_wandb false \
    --seed 2


# eval Qwen2.5-7B
bash eval_math_nodes.sh \
    --run_name qwen2.5_7b_seed2 \
    --init_model <your absolute path to>/models/Qwen2.5-7B \
    --template qwen-boxed \
    --tp_size 1 \
    --add_step_0 true \
    --temperature 0 \
    --top_p 0.95 \
    --max_tokens 16000 \
    --benchmarks aime24 \
    --n_sampling 512 \
    --just_wandb false \
    --seed 2
```

**Notes:**
- The `--init_model` must be the **absolute path** to your model directory. If you have placed it in a different directory, change it accordingly.
- You should change `--template` if you are testing other models. It controls the prompt template used for the evaluation.
- Full list of benchmarks tested: `aime24,aime25,amc23,math500,olympiadbench,minerva_math`. See dataset under `data/` for other possible benchmarks.
- You can change `--benchmarks` to test other benchmarks.
   

## Acknowledgement
The codebase is adapted from [simpleRL-reason](https://github.com/hkust-nlp/simpleRL-reason), which was based on [math-evaluation-harness](https://github.com/ZubinGou/math-evaluation-harness).